module ss14-url-patcher

go 1.22

require fyne.io/fyne/v2 v2.5.4
